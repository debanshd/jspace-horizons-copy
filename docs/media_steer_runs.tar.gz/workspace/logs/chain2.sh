#!/usr/bin/env bash
# step 6 (gates over 32 candidates, then the 64-clip runs), then step 7 once the background download of the 31B is over
. /workspace/env.sh
set -u
export CANDIDATES=32
echo "$(date -u +%T) step 6: medium models"
scripts/media_steer.sh || { echo "step 6 failed"; exit 1; }
echo "$(date -u +%T) step 6 done"
while pgrep -f "download.py --skip-data" >/dev/null; do sleep 20; done   # the first chain's downloads; media_steer.sh fetches whatever is missing
echo "$(date -u +%T) step 7: all six"
MODELS="Qwen/Qwen3.5-0.8B Qwen/Qwen3.5-4B Qwen/Qwen3.5-27B google/gemma-4-E2B-it google/gemma-4-E4B-it google/gemma-4-31B-it" RUN=media_steer_all scripts/media_steer.sh || { echo "step 7 failed"; exit 1; }
echo "$(date -u +%T) all done"
