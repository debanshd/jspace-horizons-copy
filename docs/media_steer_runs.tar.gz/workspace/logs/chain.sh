#!/usr/bin/env bash
# plan.md steps 6 and 7 back to back on this pod, with the step-7 models downloaded while step 6 uses the GPU.
. /workspace/env.sh
set -u
DL=runs/.downloads; mkdir -p "$DL"
ALL="Qwen/Qwen3.5-0.8B Qwen/Qwen3.5-4B Qwen/Qwen3.5-27B google/gemma-4-E2B-it google/gemma-4-E4B-it google/gemma-4-31B-it"
(   # in the order step 7 reaches them, one at a time; same .ok files as scripts/media_steer.sh, so it skips them
    for m in Qwen/Qwen3.5-0.8B Qwen/Qwen3.5-27B google/gemma-4-E2B-it google/gemma-4-31B-it; do
        t=${m#*/}; [ -f "$DL/$t.ok" ] && continue
        echo "$(date -u +%T) download $m"; uv run --frozen scripts/download.py --skip-data --models "$m" > "$DL/$t.log" 2>&1 && touch "$DL/$t.ok" || { echo "download of $m failed"; exit 1; }
        echo "$(date -u +%T) done $m"
    done
) > /workspace/logs/predownload.log 2>&1 &
PRE=$!
echo "$(date -u +%T) step 6: medium models"
scripts/media_steer.sh || { echo "step 6 failed"; exit 1; }
echo "$(date -u +%T) step 6 done; waiting for the downloads"
wait "$PRE" || { echo "a download failed: /workspace/logs/predownload.log"; exit 1; }
echo "$(date -u +%T) step 7: all six"
MODELS="$ALL" RUN=media_steer_all scripts/media_steer.sh || { echo "step 7 failed"; exit 1; }
echo "$(date -u +%T) all done"
